# install flask dan mysql-connector-python
# pip install Flask mysql-connector-python

from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector

app = Flask(__name__)
app.secret_key = "secret_key"

# Ganti dengan informasi database Anda
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="motor",
    autocommit=True
)

cursor = db.cursor()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor.execute('INSERT INTO users (username, password) VALUES (%s, %s)', (username, password))
        db.commit()

        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor.execute('SELECT * FROM users WHERE username = %s AND password = %s', (username, password))
        user = cursor.fetchone()

        if user:
            session['username'] = user[1]
            return redirect(url_for('index'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/index')
def index():
    if 'username' in session:
        return render_template('index.html', username=session['username'])
    else:
        return redirect(url_for('login'))
    
@app.route('/produk')
def produk():
    if 'username' in session:
        return render_template('produk.html', username=session['username'])
    else:
        return "You are not logged in."
    
@app.route('/hubungi')
def hubungi():
    if 'username' in session:
        return render_template('hubungi.html', username=session['username'])
    else:
        return "You are not logged in."
    
@app.route('/pembelian')
def pembelian():
    return render_template('pembelian.html')
    
@app.route('/order', methods=['GET', 'POST'])
def order():
    if request.method == 'POST':
        # Ambil data dari formulir
        nama = request.form['nama']
        alamat = request.form['alamat']
        telepon = request.form['telepon']
        motor_id = request.form['motor']

        # Simpan pesanan ke database
        cursor.execute("INSERT INTO pesanan (nama, alamat, telepon, motor_id) VALUES (%s, %s, %s, %s)",
                       (nama, alamat, telepon, motor_id))
        db.commit()
        
        # Ambil data pesanan dari database
        cursor.execute("SELECT * FROM pesanan WHERE id = LAST_INSERT_ID()")
        pesanan = cursor.fetchone()

        # Ambil data motor dari database
        cursor.execute("SELECT * FROM motor WHERE id = %s", (motor_id,))
        motor = cursor.fetchone()

        return render_template('sukses.html', pesanan=pesanan, motor=motor)

    # Ambil data motor dari database
    cursor.execute("SELECT * FROM motor")
    motors = cursor.fetchall()


    return render_template('order.html', motors=motors)

# ...

@app.route('/history')
def history():
    cursor.execute("SELECT pesanan.id, pesanan.nama, pesanan.alamat, pesanan.telepon, motor.nama FROM pesanan JOIN motor ON pesanan.motor_id = motor.id")
    pesanans = cursor.fetchall()
    return render_template('history.html', pesanans=pesanans)

# ...

@app.route('/sukses')
def sukses():
    return render_template('sukses.html')

if __name__ == '__main__':
    app.run(debug=True)